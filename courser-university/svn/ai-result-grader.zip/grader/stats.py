#!/usr/bin/env python3
"""
evidence-review — pure-Python statistical engine (ZERO dependencies).

Why pure Python: numpy AND scipy are broken on this Mac (x86_64/arm64 mach-o
mismatch). Only the built-in `statistics` module works. So every distribution
function here is implemented from scratch (incomplete beta / incomplete gamma /
normal CDF). Runs on any stock Python 3.9+.

Implements the nine tests from the "9 Statistical Tests for AI Leaders" card:
  1 t-test (independent / paired)   6 Kruskal-Wallis
  2 z-test (mean / proportion)      7 Pearson correlation
  3 ANOVA (one-way)                 8 Wilcoxon signed-rank
  4 chi-square                      9 Fisher's exact
  5 Mann-Whitney U

Every result carries: statistic, df, p-value, EFFECT SIZE (not just p),
sample size, and WARNINGS (assumption violations, sample too small, etc.).
Significance answers "is the delta likely real"; effect size answers "is it
big enough to matter". You need both to scale.

CLI:  python3 stats.py <test> <args...>    (run with no args for help)
Lib:  from stats import t_test_independent, chi_square, ...
"""
import math
from statistics import NormalDist, mean, pstdev, stdev

# ---------------------------------------------------------------------------
# Minimum-sample floors (advisory). Below these, normal-theory p-values and
# effect estimates are unstable — the engine flags it and the reviewer should
# print "NOT COMPARED — only n=X" rather than quote the number as fact.
# ---------------------------------------------------------------------------
MIN_N_PARAMETRIC = 10      # per group for t/ANOVA/z-mean (CLT comfort)
MIN_N_RANK       = 8       # per group for Mann-Whitney / Kruskal / Wilcoxon normal approx
MIN_N_CORR       = 10      # pairs for Pearson
MIN_EXPECTED_CELL = 5      # chi-square expected cell count

_ND = NormalDist()
def _ncdf(z): return _ND.cdf(z)
def _nppf(p): return _ND.inv_cdf(p)

# ---------------------------------------------------------------------------
# Special functions (Numerical Recipes style continued fractions)
# ---------------------------------------------------------------------------
def _betacf(a, b, x):
    MAXIT, EPS, FPMIN = 300, 3e-16, 1e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < FPMIN: d = FPMIN
    d = 1.0 / d
    h = d
    for m in range(1, MAXIT + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN: d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN: c = FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN: d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN: c = FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < EPS:
            break
    return h

def betai(a, b, x):
    """Regularized incomplete beta I_x(a,b)."""
    if x <= 0.0: return 0.0
    if x >= 1.0: return 1.0
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
    bt = math.exp(lbeta + a * math.log(x) + b * math.log(1.0 - x))
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b

def _gser(a, x):
    ITMAX, EPS = 400, 3e-16
    gln = math.lgamma(a)
    if x <= 0.0: return 0.0
    ap = a
    s = 1.0 / a
    dl = s
    for _ in range(ITMAX):
        ap += 1.0
        dl *= x / ap
        s += dl
        if abs(dl) < abs(s) * EPS:
            break
    return s * math.exp(-x + a * math.log(x) - gln)

def _gcf(a, x):
    ITMAX, EPS, FPMIN = 400, 3e-16, 1e-300
    gln = math.lgamma(a)
    b = x + 1.0 - a
    c = 1.0 / FPMIN
    d = 1.0 / b
    h = d
    for i in range(1, ITMAX + 1):
        an = -i * (i - a)
        b += 2.0
        d = an * d + b
        if abs(d) < FPMIN: d = FPMIN
        c = b + an / c
        if abs(c) < FPMIN: c = FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < EPS:
            break
    return math.exp(-x + a * math.log(x) - gln) * h

def gammq(a, x):
    """Regularized upper incomplete gamma Q(a,x) = P(X > x) for chi-square etc."""
    if x < 0.0 or a <= 0.0:
        raise ValueError("gammq domain")
    if x < a + 1.0:
        return 1.0 - _gser(a, x)
    return _gcf(a, x)

# ---- distribution tails ----
def t_sf_two(t, df):
    """Two-tailed p-value for Student's t."""
    if df <= 0: return float("nan")
    x = df / (df + t * t)
    return betai(df / 2.0, 0.5, x)

def f_sf(f, df1, df2):
    """Upper-tail p for the F distribution."""
    if f <= 0: return 1.0
    return betai(df2 / 2.0, df1 / 2.0, df2 / (df2 + df1 * f))

def chi2_sf(x, df):
    """Upper-tail p for chi-square."""
    if x <= 0: return 1.0
    return gammq(df / 2.0, x / 2.0)

def t_crit(alpha_two, df):
    """t critical value for a two-tailed alpha (bisection on t_sf_two)."""
    lo, hi = 0.0, 1000.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if t_sf_two(mid, df) > alpha_two:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)

# ---------------------------------------------------------------------------
# effect-size magnitude labels (Cohen 1988 conventions — published, not ad hoc)
# ---------------------------------------------------------------------------
def d_magnitude(d):
    a = abs(d)
    return "negligible" if a < 0.2 else "small" if a < 0.5 else "medium" if a < 0.8 else "large"

def r_magnitude(r):
    a = abs(r)
    return "negligible" if a < 0.1 else "small" if a < 0.3 else "medium" if a < 0.5 else "large"

def cramers_v_magnitude(v, df_small):
    # Cohen thresholds depend on df* = min(rows,cols)-1
    thr = {1: (0.1, 0.3, 0.5), 2: (0.07, 0.21, 0.35), 3: (0.06, 0.17, 0.29)}
    s, m, l = thr.get(max(1, df_small), (0.05, 0.15, 0.25))
    a = abs(v)
    return "negligible" if a < s else "small" if a < m else "medium" if a < l else "large"

# ---------------------------------------------------------------------------
# 1. t-test
# ---------------------------------------------------------------------------
def t_test_independent(a, b, equal_var=False, alpha=0.05):
    """Welch's t-test by default (does NOT assume equal variances)."""
    n1, n2 = len(a), len(b)
    m1, m2 = mean(a), mean(b)
    v1, v2 = stdev(a) ** 2, stdev(b) ** 2
    diff = m1 - m2
    warn = []
    if equal_var:
        dfp = n1 + n2 - 2
        sp2 = ((n1 - 1) * v1 + (n2 - 1) * v2) / dfp
        se = math.sqrt(sp2 * (1 / n1 + 1 / n2))
        df = dfp
        sd_pool = math.sqrt(sp2)
    else:
        se = math.sqrt(v1 / n1 + v2 / n2)
        df = (v1 / n1 + v2 / n2) ** 2 / ((v1 / n1) ** 2 / (n1 - 1) + (v2 / n2) ** 2 / (n2 - 1))
        sd_pool = math.sqrt(((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2))
    t = diff / se if se else float("inf")
    p = t_sf_two(t, df)
    d = diff / sd_pool if sd_pool else float("nan")
    tc = t_crit(alpha, df)
    ci = (diff - tc * se, diff + tc * se)
    if min(n1, n2) < MIN_N_PARAMETRIC:
        warn.append(f"n per group < {MIN_N_PARAMETRIC} (got {n1},{n2}) — small-sample; needs ~normal data, CI wide.")
    if v1 and v2 and (max(v1, v2) / min(v1, v2) > 4) and equal_var:
        warn.append("variances differ >4x but equal_var=True — use Welch (equal_var=False).")
    return _pack("Independent t-test (Welch)" if not equal_var else "Independent t-test (pooled)",
                 t, df, p, ("Cohen's d", d, d_magnitude(d)), (n1, n2),
                 mean_diff=diff, ci=ci, warnings=warn,
                 interpret=f"means differ by {diff:.4g} (A={m1:.4g}, B={m2:.4g})")

def t_test_paired(before, after, alpha=0.05):
    if len(before) != len(after):
        raise ValueError("paired samples must be equal length")
    diffs = [b - a for a, b in zip(before, after)]  # after - before
    n = len(diffs)
    md = mean(diffs)
    sd = stdev(diffs)
    se = sd / math.sqrt(n)
    df = n - 1
    t = md / se if se else float("inf")
    p = t_sf_two(t, df)
    dz = md / sd if sd else float("nan")
    tc = t_crit(alpha, df)
    ci = (md - tc * se, md + tc * se)
    warn = []
    if n < MIN_N_PARAMETRIC:
        warn.append(f"n < {MIN_N_PARAMETRIC} pairs (got {n}) — small-sample; paired diffs must be ~normal.")
    return _pack("Paired t-test", t, df, p, ("Cohen's dz", dz, d_magnitude(dz)), (n,),
                 mean_diff=md, ci=ci, warnings=warn,
                 interpret=f"mean change (after-before) = {md:.4g}")

# ---------------------------------------------------------------------------
# 2. z-test
# ---------------------------------------------------------------------------
def z_test_mean(sample, popmean, popsd):
    """Mean z-test — ONLY valid when the population SD is genuinely known."""
    n = len(sample)
    m = mean(sample)
    se = popsd / math.sqrt(n)
    z = (m - popmean) / se
    p = 2 * (1 - _ncdf(abs(z)))
    return _pack("Z-test (mean)", z, None, p, ("effect (z-units)", (m - popmean) / popsd, None),
                 (n,), mean_diff=m - popmean,
                 warnings=["population SD must be genuinely known; if estimated, use a t-test."],
                 interpret=f"sample mean {m:.4g} vs benchmark {popmean:.4g}")

def z_test_proportion(successes, n, p0):
    """One-proportion z-test vs a benchmark p0 (e.g. hallucination rate vs 2%)."""
    phat = successes / n
    se = math.sqrt(p0 * (1 - p0) / n)
    z = (phat - p0) / se
    p = 2 * (1 - _ncdf(abs(z)))
    warn = []
    if n * p0 < 10 or n * (1 - p0) < 10:
        warn.append("expected successes or failures < 10 — normal approx weak; consider exact/binomial test.")
    h = 2 * math.asin(math.sqrt(phat)) - 2 * math.asin(math.sqrt(p0))  # Cohen's h
    return _pack("Z-test (proportion)", z, None, p, ("Cohen's h", h, d_magnitude(h)), (n,),
                 mean_diff=phat - p0, warnings=warn,
                 interpret=f"observed rate {phat:.4g} vs benchmark {p0:.4g}")

def z_test_two_proportions(s1, n1, s2, n2):
    p1, p2 = s1 / n1, s2 / n2
    pp = (s1 + s2) / (n1 + n2)
    se = math.sqrt(pp * (1 - pp) * (1 / n1 + 1 / n2))
    z = (p1 - p2) / se
    p = 2 * (1 - _ncdf(abs(z)))
    warn = []
    for s, n, lbl in ((s1, n1, "A"), (s2, n2, "B")):
        if s < 10 or (n - s) < 10:
            warn.append(f"group {lbl}: <10 successes or failures — normal approx weak; use Fisher's exact.")
    h = 2 * math.asin(math.sqrt(p1)) - 2 * math.asin(math.sqrt(p2))
    return _pack("Z-test (two proportions)", z, None, p, ("Cohen's h", h, d_magnitude(h)),
                 (n1, n2), mean_diff=p1 - p2, warnings=warn,
                 interpret=f"rate A={p1:.4g} vs B={p2:.4g}")

# ---------------------------------------------------------------------------
# 3. ANOVA (one-way)
# ---------------------------------------------------------------------------
def anova_oneway(*groups):
    k = len(groups)
    N = sum(len(g) for g in groups)
    grand = mean([x for g in groups for x in g])
    ssb = sum(len(g) * (mean(g) - grand) ** 2 for g in groups)
    ssw = sum(sum((x - mean(g)) ** 2 for x in g) for g in groups)
    dfb, dfw = k - 1, N - k
    msb, msw = ssb / dfb, ssw / dfw
    f = msb / msw if msw else float("inf")
    p = f_sf(f, dfb, dfw)
    eta2 = ssb / (ssb + ssw) if (ssb + ssw) else float("nan")
    warn = ["significant result needs post-hoc pairwise tests to say WHICH groups differ."]
    if any(len(g) < MIN_N_PARAMETRIC for g in groups):
        warn.append(f"a group has n < {MIN_N_PARAMETRIC} — small-sample; residuals should be ~normal, variances similar.")
    return _pack("One-way ANOVA", f, (dfb, dfw), p, ("eta-squared", eta2,
                 "small" if eta2 < 0.06 else "medium" if eta2 < 0.14 else "large"),
                 tuple(len(g) for g in groups), warnings=warn,
                 interpret=f"{k} group means; at least one differs" if p < 0.05 else f"{k} group means; no clear difference")

# ---------------------------------------------------------------------------
# 4. chi-square (contingency)
# ---------------------------------------------------------------------------
def chi_square(table):
    """table = list of rows (list of counts). Tests association of two categoricals."""
    rows = len(table)
    cols = len(table[0])
    rt = [sum(r) for r in table]
    ct = [sum(table[i][j] for i in range(rows)) for j in range(cols)]
    n = sum(rt)
    chi2 = 0.0
    min_exp = float("inf")
    for i in range(rows):
        for j in range(cols):
            e = rt[i] * ct[j] / n
            min_exp = min(min_exp, e)
            if e > 0:
                chi2 += (table[i][j] - e) ** 2 / e
    df = (rows - 1) * (cols - 1)
    p = chi2_sf(chi2, df)
    dstar = min(rows, cols) - 1
    v = math.sqrt(chi2 / (n * dstar)) if dstar else float("nan")
    warn = []
    if min_exp < MIN_EXPECTED_CELL:
        warn.append(f"smallest expected cell = {min_exp:.2g} < {MIN_EXPECTED_CELL} — chi-square unreliable; use Fisher's exact (esp. 2x2).")
    return _pack("Chi-square", chi2, df, p, ("Cramer's V", v, cramers_v_magnitude(v, dstar)),
                 (n,), warnings=warn,
                 interpret="association present" if p < 0.05 else "no clear association")

# ---------------------------------------------------------------------------
# rank helper
# ---------------------------------------------------------------------------
def _ranks(values):
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    tie_groups = []
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        avg = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        if j > i:
            tie_groups.append(j - i + 1)
        i = j + 1
    return ranks, tie_groups

# ---------------------------------------------------------------------------
# 5. Mann-Whitney U (normal approx, tie + continuity corrected)
# ---------------------------------------------------------------------------
def mann_whitney_u(a, b):
    n1, n2 = len(a), len(b)
    ranks, ties = _ranks(list(a) + list(b))
    r1 = sum(ranks[:n1])
    u1 = r1 - n1 * (n1 + 1) / 2.0
    u2 = n1 * n2 - u1
    u = min(u1, u2)
    N = n1 + n2
    mu = n1 * n2 / 2.0
    tie_term = sum(t ** 3 - t for t in ties)
    var = n1 * n2 / 12.0 * ((N + 1) - tie_term / (N * (N - 1)))
    z = (u - mu + 0.5) / math.sqrt(var) if var else 0.0
    p = 2 * (1 - _ncdf(abs(z)))
    rb = 1 - 2 * u1 / (n1 * n2)  # rank-biserial
    warn = []
    if min(n1, n2) < MIN_N_RANK:
        warn.append(f"min group n < {MIN_N_RANK} — normal approximation unreliable; use exact Mann-Whitney.")
    return _pack("Mann-Whitney U", u, None, p, ("rank-biserial r", rb, r_magnitude(rb)),
                 (n1, n2), warnings=warn,
                 interpret="rank distributions differ" if p < 0.05 else "no clear rank difference")

# ---------------------------------------------------------------------------
# 6. Kruskal-Wallis
# ---------------------------------------------------------------------------
def kruskal_wallis(*groups):
    all_vals = [x for g in groups for x in g]
    N = len(all_vals)
    ranks, ties = _ranks(all_vals)
    idx = 0
    H = 0.0
    for g in groups:
        rsum = sum(ranks[idx:idx + len(g)])
        idx += len(g)
        H += rsum ** 2 / len(g)
    H = 12.0 / (N * (N + 1)) * H - 3 * (N + 1)
    C = 1 - sum(t ** 3 - t for t in ties) / (N ** 3 - N) if (N ** 3 - N) else 1.0
    if C: H /= C
    k = len(groups)
    df = k - 1
    p = chi2_sf(H, df)
    eta2 = (H - k + 1) / (N - k) if (N - k) else float("nan")
    warn = ["significant result needs follow-up pairwise tests."]
    if any(len(g) < MIN_N_RANK for g in groups):
        warn.append(f"a group has n < {MIN_N_RANK} — chi-square approx to H unreliable.")
    return _pack("Kruskal-Wallis", H, df, p, ("epsilon-squared", eta2,
                 "small" if eta2 < 0.06 else "medium" if eta2 < 0.14 else "large"),
                 tuple(len(g) for g in groups), warnings=warn,
                 interpret="at least one group's ranks differ" if p < 0.05 else "no clear rank difference")

# ---------------------------------------------------------------------------
# 7. Pearson correlation
# ---------------------------------------------------------------------------
def pearson_r(x, y):
    if len(x) != len(y):
        raise ValueError("x and y must be equal length")
    n = len(x)
    mx, my = mean(x), mean(y)
    sxy = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y))
    sxx = sum((xi - mx) ** 2 for xi in x)
    syy = sum((yi - my) ** 2 for yi in y)
    r = sxy / math.sqrt(sxx * syy) if sxx and syy else float("nan")
    df = n - 2
    t = r * math.sqrt(df / (1 - r ** 2)) if abs(r) < 1 else float("inf")
    p = t_sf_two(t, df)
    warn = ["correlation != causation; assumes a roughly LINEAR relationship, no major outliers."]
    if n < MIN_N_CORR:
        warn.append(f"n < {MIN_N_CORR} pairs — r is unstable at this sample size.")
    return _pack("Pearson correlation", t, df, p, ("r (and r^2=%.3f)" % (r * r), r, r_magnitude(r)),
                 (n,), warnings=warn,
                 interpret=f"r = {r:.3f} ({'positive' if r > 0 else 'negative'} linear association)")

# ---------------------------------------------------------------------------
# 8. Wilcoxon signed-rank (paired, non-normal)
# ---------------------------------------------------------------------------
def wilcoxon_signed_rank(before, after):
    if len(before) != len(after):
        raise ValueError("paired samples must be equal length")
    diffs = [b - a for a, b in zip(before, after)]  # after - before
    nz = [d for d in diffs if d != 0]
    n = len(nz)
    ranks, ties = _ranks([abs(d) for d in nz])
    wpos = sum(rk for d, rk in zip(nz, ranks) if d > 0)
    wneg = sum(rk for d, rk in zip(nz, ranks) if d < 0)
    W = min(wpos, wneg)
    mu = n * (n + 1) / 4.0
    var = n * (n + 1) * (2 * n + 1) / 24.0 - sum(t ** 3 - t for t in ties) / 48.0
    z = (W - mu + 0.5) / math.sqrt(var) if var else 0.0
    p = 2 * (1 - _ncdf(abs(z)))
    rb = (wpos - wneg) / (n * (n + 1) / 2.0) if n else float("nan")
    warn = ["assumes paired differences are roughly SYMMETRIC."]
    if n < MIN_N_RANK + 2:
        warn.append(f"only {n} non-zero pairs — normal approx unreliable; use exact Wilcoxon.")
    return _pack("Wilcoxon signed-rank", W, None, p, ("rank-biserial r", rb, r_magnitude(rb)),
                 (n,), warnings=warn,
                 interpret="paired distributions differ" if p < 0.05 else "no clear paired difference")

# ---------------------------------------------------------------------------
# 9. Fisher's exact (2x2)
# ---------------------------------------------------------------------------
def fisher_exact(table):
    (a, b), (c, d) = table
    n = a + b + c + d
    r1, r2 = a + b, c + d
    c1 = a + c
    def hyp(k):
        return math.comb(r1, k) * math.comb(r2, c1 - k) / math.comb(n, c1)
    kmin, kmax = max(0, c1 - r2), min(c1, r1)
    p_obs = hyp(a)
    p_two = sum(hyp(k) for k in range(kmin, kmax + 1) if hyp(k) <= p_obs * (1 + 1e-7))
    # odds ratio (Haldane-Anscombe correction if a zero cell)
    aa, bb, cc, dd = a, b, c, d
    if 0 in (a, b, c, d):
        aa, bb, cc, dd = a + 0.5, b + 0.5, c + 0.5, d + 0.5
    orat = (aa * dd) / (bb * cc)
    warn = ["designed for small/sparse 2x2 — exact, no large-sample assumption."]
    return _pack("Fisher's exact (2x2)", None, None, min(p_two, 1.0),
                 ("odds ratio", orat, "large" if orat > 3 or orat < 1/3 else "small"),
                 (n,), warnings=warn,
                 interpret=f"odds ratio = {orat:.3g}")

# ---------------------------------------------------------------------------
# packaging + pretty print
# ---------------------------------------------------------------------------
def _pack(test, stat, df, p, effect, ns, mean_diff=None, ci=None, warnings=None, interpret=""):
    return {
        "test": test, "statistic": stat, "df": df, "p_value": p,
        "effect_name": effect[0], "effect": effect[1], "effect_magnitude": effect[2],
        "n": ns, "mean_diff": mean_diff, "ci95": ci,
        "warnings": warnings or [], "interpret": interpret,
    }

def report(res, alpha=0.05):
    lines = [f"TEST: {res['test']}"]
    if res["statistic"] is not None:
        lines.append(f"  statistic = {res['statistic']:.4g}" +
                     (f"   df = {res['df']}" if res["df"] is not None else ""))
    lines.append(f"  p-value   = {res['p_value']:.4g}   ->  " +
                 ("SIGNIFICANT (unlikely random)" if res["p_value"] < alpha
                  else "NOT significant at alpha=%.2g" % alpha))
    if res["effect"] is not None and not (isinstance(res["effect"], float) and math.isnan(res["effect"])):
        mag = f" ({res['effect_magnitude']})" if res["effect_magnitude"] else ""
        lines.append(f"  effect    = {res['effect_name']} = {res['effect']:.4g}{mag}   <- does it MATTER?")
    if res["mean_diff"] is not None:
        lines.append(f"  mean diff = {res['mean_diff']:.4g}")
    if res["ci95"] is not None:
        lo, hi = res["ci95"]
        spans0 = lo <= 0 <= hi
        lines.append(f"  95% CI    = [{lo:.4g}, {hi:.4g}]" +
                     ("   ** spans 0 — direction not established **" if spans0 else ""))
    lines.append(f"  n         = {res['n']}")
    if res["interpret"]:
        lines.append(f"  reads as  : {res['interpret']}")
    for w in res["warnings"]:
        lines.append(f"  [!] {w}")
    return "\n".join(lines)

# ---------------------------------------------------------------------------
# CLI  (numbers as comma-separated lists; tables as semicolon-separated rows)
# ---------------------------------------------------------------------------
def _nums(s): return [float(x) for x in s.replace(" ", "").split(",") if x != ""]
def _table(s): return [[float(x) for x in row.split(",")] for row in s.split(";")]

def _cli():
    import sys
    args = sys.argv[1:]
    help_txt = """evidence-review stats engine — CLI

  ttest_ind   "a1,a2,.." "b1,b2,.."        independent (Welch) t-test
  ttest_paired "before.." "after.."         paired t-test
  ztest_mean  "sample.." popmean popsd       mean vs known-SD benchmark
  ztest_prop  successes n p0                 one proportion vs benchmark
  ztest_2prop s1 n1 s2 n2                    two proportions
  anova       "g1.." "g2.." "g3.." ...       one-way ANOVA
  chi2        "r1c1,r1c2;r2c1,r2c2;.."       contingency chi-square
  mannwhitney "a.." "b.."                    Mann-Whitney U
  kruskal     "g1.." "g2.." ...              Kruskal-Wallis
  pearson     "x.." "y.."                    Pearson correlation
  wilcoxon    "before.." "after.."           Wilcoxon signed-rank
  fisher      "a,b;c,d"                       Fisher's exact 2x2

Every result prints statistic, p-value, EFFECT SIZE, CI, n, and warnings.
p answers 'likely real?'; effect answers 'big enough to matter?'. Need both.
"""
    if not args or args[0] in ("-h", "--help", "help"):
        print(help_txt); return
    cmd = args[0]
    try:
        if cmd == "ttest_ind":    r = t_test_independent(_nums(args[1]), _nums(args[2]))
        elif cmd == "ttest_paired": r = t_test_paired(_nums(args[1]), _nums(args[2]))
        elif cmd == "ztest_mean": r = z_test_mean(_nums(args[1]), float(args[2]), float(args[3]))
        elif cmd == "ztest_prop": r = z_test_proportion(float(args[1]), float(args[2]), float(args[3]))
        elif cmd == "ztest_2prop": r = z_test_two_proportions(float(args[1]), float(args[2]), float(args[3]), float(args[4]))
        elif cmd == "anova":      r = anova_oneway(*[_nums(a) for a in args[1:]])
        elif cmd == "chi2":       r = chi_square(_table(args[1]))
        elif cmd == "mannwhitney": r = mann_whitney_u(_nums(args[1]), _nums(args[2]))
        elif cmd == "kruskal":    r = kruskal_wallis(*[_nums(a) for a in args[1:]])
        elif cmd == "pearson":    r = pearson_r(_nums(args[1]), _nums(args[2]))
        elif cmd == "wilcoxon":   r = wilcoxon_signed_rank(_nums(args[1]), _nums(args[2]))
        elif cmd == "fisher":     r = fisher_exact([[int(x) for x in row] for row in _table(args[1])])
        else:
            print(f"unknown command: {cmd}\n"); print(help_txt); return
        print(report(r))
    except (IndexError, ValueError) as e:
        print(f"error: {e}\n"); print(help_txt)

if __name__ == "__main__":
    _cli()
