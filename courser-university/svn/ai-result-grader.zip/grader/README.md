# The AI Result Grader — evidence-review

The working toolkit behind **Signal vs Noise: Evidence Discipline for AI Leaders**.
Three files, no dependencies, nothing to sign up for.

| File | What it is |
|---|---|
| `SKILL.md` | The grader itself — two modes (grade a RESULT, or audit the evidence in a DRAFT), the test selector, the seven gates, and the SCALE / HOLD / NO rules. |
| `nine-tests.md` | The reference card: each test's job, when to use it, what it **assumes**, the effect size to demand alongside p, and its AI example. |
| `stats.py` | The engine. Pure Python 3, zero dependencies — prints statistic, p-value, **effect size**, 95% interval, n, and every assumption warning. |

## Use it in 30 seconds

```
python3 stats.py                                  # list every command
python3 stats.py ztest_2prop 340 5000 400 5000    # the module 2 worked case
python3 stats.py ttest_paired "16.2,14.8,..." "13.9,14.1,..."
```

That first command reproduces the exact result from module 2 of the course —
p = 0.0219, Cohen's h = −0.046. Significant and negligible, at the same time.

## Use it as an installable skill

Drop the folder into `~/.claude/skills/evidence-review/` (with `nine-tests.md`
under `references/` and `stats.py` under `scripts/`) and your assistant will run
the whole review — pick the test, check its assumptions, compute the stats, walk
the seven gates, and return a verdict with the cheapest next test.

## The one rule

The verdict follows the gates, not the wish. UNKNOWN counts as FAIL, minimum-n
suppression is mandatory, and SCALE never means "do it" — it means cost and
capacity are now the only open questions.
