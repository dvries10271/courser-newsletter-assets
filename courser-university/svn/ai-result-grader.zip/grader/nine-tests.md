# Nine Statistical Tests for AI Leaders — reference card

Source framing: Michael Lee, *"9 Statistical Tests for AI Leaders — nine ways to
know whether a result is signal or noise."* You don't need to run these
yourself. You need to know they exist so you can **ask whether anyone did.**

"Start with the hypothesis and the data structure. *Normal vs non-normal is not
enough.*" For each test: what it's for · when to use it · what it **assumes**
(assumptions are where results break) · the effect size to demand alongside p ·
the engine command.

Engine: `python3 ~/.claude/skills/evidence-review/scripts/stats.py <cmd> <args>`
(pure Python, zero deps; prints statistic, p, effect size, 95% CI, n, warnings).

---

## 1. T-Test — compare two means
- **Use when:** outcome is continuous; two groups, independent OR paired; no
  major outliers; for small samples the values (or paired differences) are
  ~normal.
- **Types:** Independent (two separate groups) · Paired (same units, before/after).
- **Assumes:** independence within groups; ~normal (esp. small n); Welch variant
  drops the equal-variance assumption (the engine defaults to Welch).
- **Effect size:** Cohen's d (0.2 small / 0.5 medium / 0.8 large). A significant
  t on d≈0.1 is a real-but-trivial difference.
- **AI example:** average handle time for analysts on workflow A vs B.
- **Engine:** `ttest_ind "a.." "b.."` · `ttest_paired "before.." "after.."`

## 2. Z-Test — compare a mean or proportion to a reference value
- **Use when:** *mean* z-test needs the population SD genuinely KNOWN (rare — if
  you estimated it, use a t-test). *Proportion* z-test needs expected successes
  AND failures both large enough (≥~10).
- **Assumes:** known SD (mean) / large-enough counts (proportion); independence.
- **Effect size:** Cohen's h (proportions); (mean−benchmark)/SD (mean).
- **AI example:** test whether the hallucination rate differs from a 2% benchmark.
- **Engine:** `ztest_prop successes n p0` · `ztest_2prop s1 n1 s2 n2` · `ztest_mean "sample.." popmean popsd`

## 3. ANOVA — test whether at least one of 3+ group means differs
- **Use when:** outcome is continuous; 3+ independent groups; residuals ~normal;
  variances reasonably similar.
- **Note:** a significant result only says *at least one* differs — it needs
  **post-hoc pairwise tests** to say which.
- **Effect size:** eta² (0.01 small / 0.06 medium / 0.14 large).
- **AI example:** task completion time across 3 model or workflow designs.
- **Engine:** `anova "g1.." "g2.." "g3.."`

## 4. Chi-Square — association between two categorical variables
- **Use when:** data are counts in categories; observations independent;
  **expected** cell counts sufficiently large (≥5). For 2×2 or sparse, prefer
  Fisher's exact (test 9).
- **Assumes:** independence; adequate expected counts (the engine warns if not).
- **Effect size:** Cramér's V.
- **AI example:** whether escalation outcome is associated with model assignment.
- **Engine:** `chi2 "r1c1,r1c2;r2c1,r2c2"`

## 5. Mann-Whitney U — compare rank distributions of two independent groups
- **Use when:** outcome is ordinal, OR continuous but non-normal; two independent
  groups.
- **Note:** reflects a median/location shift when the two shapes are similar.
- **Assumes:** independent observations; the engine's normal approximation needs
  each group ≳8 (warns otherwise → use exact).
- **Effect size:** rank-biserial r.
- **AI example:** user satisfaction scores between two chatbot versions.
- **Engine:** `mannwhitney "a.." "b.."`

## 6. Kruskal-Wallis — compare rank distributions across 3+ independent groups
- **Use when:** outcome is ordinal, or continuous non-normal; 3+ independent groups.
- **Note:** significant → needs follow-up pairwise tests.
- **Effect size:** epsilon²/eta²_H.
- **AI example:** agent quality ratings across three workflow designs.
- **Engine:** `kruskal "g1.." "g2.." "g3.."`

## 7. Pearson Correlation — strength of a LINEAR relationship between two quantitatives
- **Use when:** relationship is roughly linear; observations independent; no
  major outliers.
- **Note:** **correlation does not imply causation.** A non-linear relationship
  can show r≈0 while being strongly related — always eyeball the scatter.
- **Effect size:** r itself (0.1 / 0.3 / 0.5) and r² (variance explained).
- **AI example:** relationship between prompt length and response latency.
- **Engine:** `pearson "x.." "y.."`

## 8. Wilcoxon Signed-Rank — compare two related samples via paired differences
- **Use when:** data are paired; differences are not normal but are roughly
  symmetric.
- **Assumes:** paired; ~symmetric differences; engine warns for tiny n.
- **Effect size:** rank-biserial r.
- **AI example:** analyst productivity before vs after an AI copilot rollout.
- **Engine:** `wilcoxon "before.." "after.."`

## 9. Fisher's Exact — association in a contingency table, small/sparse sample
- **Use when:** categorical data in a small or sparse sample, especially a 2×2.
  The exact test — no large-sample assumption, so it's the right call when
  chi-square's expected-count rule fails.
- **Effect size:** odds ratio.
- **AI example:** whether a rare failure event is associated with guardrail
  on vs off in a small pilot.
- **Engine:** `fisher "a,b;c,d"`

---

## The judgment layer the card implies (from the discussion under the post)

The test is necessary, not sufficient. Every reviewer worth reading added the
same point: statistical significance answers whether a measured difference is
likely real *under the test conditions* — leadership still has to ask whether
those conditions **created** the result and whether they'll **exist at scale.**

- **Counterfactual (Zinkov):** what would have happened without the AI? Was there
  a credible control?
- **Behavior change during the pilot:** did people act differently *because* it
  was a pilot? Did unusually engaged users or extra support inflate the delta?
- **Representativeness:** does the sample reflect the conditions the system faces
  at scale, or hand-picked cases?
- **Effect vs significance (Charan K):** significance says "unlikely random";
  effect size + business impact say "large enough to matter." Scale needs both.
- **Materiality (Ellison):** does it move revenue, profitability, or an insight
  that supports either? Decide this in planning, then measure it in production.
- **Operating model (Ahmed):** if people still improvise when to trust or
  escalate, the value won't reproduce at scale even if the metric moved.
- **Falsifiability (Puar):** "what would make us change our mind?" If a pilot
  can't define the evidence needed to scale OR stop, it can't distinguish
  genuine value from early optimism.
- **Peeking / independence (the gate the card omits):** the dominant real
  failure in A/B and campaign work isn't a wrong test — it's **optional stopping**
  (checking daily, stopping the moment it's significant), **multiple comparisons**
  (many metrics, one crossed .05), and **non-independent observations** (multiple
  conversions per account, repeated measures on the same users). Any of these
  makes a fixed-n p-value garbage-in-precise-out. Ask before trusting any p.

> "I have watched impressive uplifts vanish the moment the sample expanded. The
> model was fine. The evidence was not." — the whole reason this skill exists.

## Source discipline for the motivating thesis

The "most AI pilots don't scale" framing is real and triple-sourced — but cite
it honestly. The reports name **integration / linking AI to the P&L** as the
root cause; *"evidence discipline is the scarce skill"* is our own inference,
not their finding. Never present the inference as the report's claim.

- MIT NANDA, *The GenAI Divide: State of AI in Business 2025* — ~95% of
  enterprise GenAI pilots show no measurable P&L return.
- BCG, *Build for the Future 2025* — ~60% report no measurable value; ~5%
  "future-built"; ~a third of the dissatisfied say it worked in pilot but
  didn't scale.
- Bain 2025 — corroborates the pilot-to-production gap.

And an honesty note on this skill's own engine: an LLM reliably *picks* the
right test but can *rationalize* a desired verdict. That's why the math is
deterministic Python and the verdict is gate-driven and skeptical by default —
not a vibe from the model.

## Worked example (Mode A)

**Claim:** "Copilot pilot cut average handle time 18% — ship it."
**Structure:** continuous outcome, same analysts before/after → paired.
**Test:** paired t-test. `ttest_paired "b1,.." "a1,.."`
**Gates:** n=12 (below floor → CI wide) · no control group (counterfactual ✗) ·
2-week window (novelty risk) · effect size real but CI may span 0.
**Verdict:** **HOLD** — significance unproven at n=12, no counterfactual.
Cheapest next test: expand to n≈40 with a holdout group over 6+ weeks.
**Actually proves:** these 12 analysts were faster during a 2-week pilot — not
that Copilot cuts handle time at scale.
