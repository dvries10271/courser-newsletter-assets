---
name: evidence-review
description: Pressure-tests a CLAIMED RESULT or the evidence inside a draft — does the evidence actually support the conclusion? Picks the right statistical test from the nine an AI leader should know, checks that test's assumptions, computes the real stats when raw numbers are given (pure-Python, zero deps), and gates on significance, effect size, sample adequacy, counterfactual, representativeness, and scale-decay. Returns SCALE / HOLD / NO + the cheapest next test. Use when Danny says "evidence review," "is this signal or noise," "does this result hold up," "pressure-test this stat/number/pilot/A-B test/eval," or before a stat headlines a campaign result, model eval, deck, essay, thought-leadership article, or eBook. Bucket: Performance.
---

# Evidence Review

The scarce skill is no longer producing a result — AI produces a delta from
every eval, A/B test, and pilot. The scarce skill is knowing **which results
deserve a decision.** This skill is that discipline, packaged: it asks the one
question a good number can hide from — *did the evidence support the
conclusion?* — and refuses to let a positive pilot pass as scalable evidence.

It pairs with the family: `validate-plan` validates a **plan**, `roast` attacks
a **new idea** — this validates a **claimed result / number / stat**.

## When this skill runs

- `/evidence-review`, "is this signal or noise," "does this result hold up,"
  "pressure-test this number / stat / pilot / A-B test / eval," "which test
  should we have run," "check the evidence in this draft/essay/eBook."
- Naturally before any number **headlines** a campaign result, per-geo
  greenlight, model eval, deck, thought-leadership article, or eBook.
- **Anti-triggers:** don't fire for a strategy/plan doc (that's `validate-plan`),
  a brand-new untested idea (that's `roast`), or "which Claude model is newest"
  (that's `claude-api`). Manual invoke — never auto-fire on a quick lookup.

## What this skill does NOT do

- Does not manufacture certainty. If the inputs can't support a verdict
  (no sample size, no counterfactual, n below floor), it says so — that IS
  the finding. Never grade on a curve to make a weak result pass.
- Does not treat statistical significance as sufficient. A significant p on a
  trivial effect, or a huge effect on n=6, is not a decision.
- **Does not decide the business go/no-go.** SCALE means "the effect is real and
  material" — NOT "you should do it." Cost, capacity, and opportunity are inputs
  this skill never sees (see Danny's capacity gate). It grades the *evidence*,
  leadership makes the *call*.
- **Is not the whole data-integrity system** — it's the narrow *pre-headline
  stats gate*. Provenance failures (banking uncoded revenue, crediting a
  back-solved constant as a measurement) are caught by the standing rules, not
  here. Don't oversell it as more than it is.
- Does not bake the Bain/BCG/MIT "95% don't scale" figures (or any
  secondary-source stat) in as a benchmark. They are motivation only,
  source-tagged, and the "evidence discipline is the scarce skill" line is an
  *inference* beyond what those reports literally claim (they name
  integration / P&L linkage as the root cause) — never present it as their finding.
- Does not run tests you can't see — it prints the statistic, p, effect, CI,
  n, and every assumption warning, so the reasoning is auditable.
- **Does not let the model narrate its way to SCALE.** The verdict defaults to
  the skeptical side and must be earned against the gates (see step 6) — a
  reframe as "just reporting uncertainty" does not unlock a softer verdict.

## Two modes

**Mode A — review a RESULT.** Input: a claimed number + its context (what was
compared, how many, over what window, with/without a control). Output: the
right test, assumption check, computed stats (if raw data given), the gate
checklist, and a verdict.

**Mode B — review the EVIDENCE IN A DRAFT.** Input: an essay, article, deck, or
eBook/whitepaper. Output: every load-bearing stat flagged and tagged
`MEASURED` (first-party) / `~estimate` / `external benchmark` / `DEAD`
(vendor-blog / Forbes-council / SEO content — never headline it), each traced
to a primary source, plus any n=1 anecdote acting as the spine of an argument.

## Workflow

### 1. Frame the hypothesis and the data structure (before picking a test)
"Normal vs non-normal is not enough." Establish:
- **What is being claimed?** (A beats B · rate differs from a benchmark · X
  correlates with Y · at least one of several differs)
- **Outcome type:** continuous · proportion/rate · rank/ordinal · categorical
- **Groups:** one-vs-benchmark · two · three+ · paired (same units before/after)
- **Distribution & sample size:** roughly normal? outliers? n per group?

### 2. Pick the right test (see `references/nine-tests.md` for the full card)

| You have… | Test |
|---|---|
| 2 means, continuous, independent or paired, ~normal | **t-test** (1) |
| a mean or proportion vs a known benchmark, SD known / n large | **z-test** (2) |
| 3+ group means, continuous, ~normal | **ANOVA** (3) → post-hoc |
| association between two categoricals, counts, cells ≥5 | **chi-square** (4) |
| 2 groups, ordinal or non-normal continuous | **Mann-Whitney U** (5) |
| 3+ groups, ordinal or non-normal continuous | **Kruskal-Wallis** (6) → post-hoc |
| strength of linear link between two quantitatives | **Pearson r** (7) |
| paired samples, non-normal but ~symmetric | **Wilcoxon signed-rank** (8) |
| 2×2 categorical, small/sparse sample | **Fisher's exact** (9) |

If the claimed number was produced with a *different* test than the data
structure calls for, that mismatch is itself a finding.

### 3. Check that test's assumptions
Each card names its assumptions (independence, ~normality, equal variances,
expected cell counts, symmetry, linearity, no major outliers). Name any that
the described setup violates.

### 4. Compute the real stats (when raw numbers exist)
Use the engine — it returns statistic, p, **effect size**, 95% CI, n, and
assumption warnings:
```bash
python3 ~/.claude/skills/evidence-review/scripts/stats.py <test> <args>
# e.g. two-proportion A/B:   ztest_2prop 340 5000 402 5000
#      before/after pilot:   ttest_paired "b1,b2,.." "a1,a2,.."
#      2x2 rare event:       fisher "a,b;c,d"
# run with no args for the full command list
```
Report significance AND effect side by side. `p` answers *likely real?*;
effect size answers *big enough to matter?* You need both to scale.

### 5. Run the seven-gate checklist (this is where pilots die)
The stats are necessary, not sufficient. The load-bearing gates are the *soft*
ones (4–6) — the p-value rarely decides it. Grade every gate PASS / FAIL /
UNKNOWN from what's actually in front of you; **UNKNOWN counts as FAIL for the
verdict** (you can't scale on evidence you don't have).

1. **Right test + assumptions met?** (steps 2–3) — and was the test **peeked**?
   Optional stopping (checking daily, stopping when it hits significance),
   multiple comparisons (many metrics, one won), or **non-independent
   observations** (multiple conversions per account, repeated measures on the
   same users) all invalidate a fixed-n p-value. This is the dominant real
   failure mode in A/B and campaign work — ask before trusting any p.
2. **Significant AND material?** Not just p < .05 — is the effect size large
   enough to change a decision, and is it tied to revenue / cost / risk /
   productivity? A significant-but-trivial delta is noise with a p-value.
3. **Sample adequate?** Below the engine's floor, print
   **"NOT COMPARED — only n=X"** instead of the number. Suppress any ratio on
   a tiny base (a "0% vs 35%" on n=2 is an artifact, not a result).
4. **Counterfactual?** Was there a control / holdout, or a credible "what would
   have happened without the AI"? A before/after with no control is a story,
   not evidence. *This is the single highest-value gate.*
5. **Representative conditions?** Hand-picked cases, unusually engaged users,
   extra support during the pilot, novelty effect, behavior change *because*
   it was a pilot? A result that depends on the pilot's conditions won't scale.
6. **Where does it decay?** Name where the effect weakens — new users,
   different workflows, exception/edge cases, higher volume, operating
   pressure. "Where will this delta survive?" is the real question.
7. **Falsifiable?** "What evidence would change our mind?" If the team can't
   state what would reverse the conclusion, they're collecting support for a
   decision already made, not testing a hypothesis.

### 6. Return the verdict — skeptical by default, earned against the gates
**The verdict is driven by the gates, not by how good the number looks or how
much anyone wants it to pass.** Start at the skeptical end and make SCALE *earn*
its way up. Before ever awarding SCALE, first write the strongest case AGAINST
scaling — if you can't refute it, the verdict is not SCALE.

- **SCALE** — the effect is real and material. Requires ALL of: right test,
  assumptions hold, not peeked, effect significant AND material, sample above
  floor, counterfactual exists, conditions representative, decay understood.
  *Any gate FAIL or UNKNOWN → cannot be SCALE.* And SCALE still isn't a
  business go — it says the evidence is strong enough that cost/capacity is now
  the only open question.
- **HOLD — need more evidence** — promising but a gate is unmet or UNKNOWN.
  Name the failed gate and the single cheapest test that closes it (usually:
  add a control, expand the sample, or re-run under operating conditions).
  **This is the default when raw data is missing** (see graceful-degrade below).
- **NO** — the evidence contradicts or cannot support the conclusion (wrong
  test, peeked, n too small, no counterfactual, significant-but-immaterial, or
  a dead-source stat).

**Graceful degrade (no raw numbers).** Most claims arrive as "i.t.NOW's page
converted better," not a column of data. Do NOT stop at "insufficient data to
compute." Run gates 2–7 as a judgment checklist anyway, cap the verdict at HOLD
(you can't earn SCALE without the computed evidence), and make the **cheapest
next test to GET the number** the headline output — that line is worth more than
any p-value.

Always close with one plain line: **"What this result actually proves: ___"** —
usually narrower than the claim.

## Output format

**Lead with, in this order:** (1) the verdict badge, (2) the failed/weakest gate
in one line, (3) the cheapest next test. That trio is the whole value — put it
first. THEN the supporting detail: "what this actually proves," the test
(chosen vs used), the computed stats block (if any), and the full seven-gate
table (PASS/FAIL/UNKNOWN + note per gate). The CI/p printout is evidence, not
the headline — never bury the verdict under it. In Mode B, a per-claim table:
claim → source → tag (MEASURED/~est/benchmark/DEAD) → keep/cut.

## Rules and guardrails

- **Skeptical by default — argue against the result before endorsing it.** The
  operator invoking this usually *wants* SCALE, and that wanting is exactly the
  pressure that produces motivated p-hacking (documented for LLMs on this task).
  Default to the null-preserving verdict; make SCALE earn its way past every
  gate; never let "it's just uncertainty reporting" reframe a FAIL into a pass.
- **The verdict follows the gates, not the wish.** If gates fail, the verdict is
  HOLD/NO no matter how clean the p-value or how much is riding on it.
- **Quality of evidence over persuasiveness of the slide.** A number that looks
  good is the input to this skill, not the output.
- **Data-integrity rules are in force** (they predate this skill): tag every
  figure MEASURED / ~estimate / external benchmark; never bank untracked or
  uncoded revenue; trace load-bearing stats to a primary source and never
  headline a dead vendor-blog / Forbes-council / SEO stat; date-stamp
  fast-aging AI research and frame test percentages as snapshots.
- **Never fabricate a p-value, effect size, or sample.** If the raw data isn't
  provided, say what test WOULD apply and what numbers you'd need — don't invent.
- **Minimum-n suppression is mandatory**, not advisory — below the floor, print
  "NOT COMPARED — only n=X" and let no downstream sentence draw a conclusion
  from it.
- **Correlation is not causation**; a significant result is not a material one;
  a positive pilot is not scalable evidence. Say each out loud when relevant.
- The engine's rank tests (Mann-Whitney / Kruskal / Wilcoxon) use a
  tie-corrected normal approximation — for tiny n it warns; escalate to an
  exact test rather than trusting the approximation.

## Self-improvement

- After each run, note any test the reviewer had to override (a mismatch the
  selector missed, a gate that didn't apply). 3+ same corrections → update the
  selector table or the gate list.
- When a new class of claim recurs (a specific A/B design, a geo scoring
  rubric), add a worked example to `references/nine-tests.md`.
- Working well = the verdict survives Danny's own challenge ("where does this
  number come from?") without a follow-up correction.
```
